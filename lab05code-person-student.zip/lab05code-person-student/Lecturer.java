package lab05src;

public class Lecturer extends Person {

}